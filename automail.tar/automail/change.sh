#!/bin/bash
# Script to update user password in batch mode
# You must be a root user to use this script
# -------------------------------------------------------------------------
# Copyright (c) 2005 nixCraft project 
# This script is licensed under GNU GPL version 2.0 or above
# -------------------------------------------------------------------------
# This script is part of nixCraft shell script collection (NSSC)
# Visit http://bash.cyberciti.biz/ for more information.
# ----------------------------------------------------------------------
# /root is good place to store clear text password
FILE="/root/automail/new.passwd"
# get all non-root user account
# By default on most linux non-root uid starts
# Group ID from 90000
USERS=$(awk -F: '{ if ( $4 > 90000 ) print $1}' /etc/passwd)
 
# create file with random password
echo "Generating file, please wait..."
 
# overwrite file, this is bash specific a better solution is cat > $FILE
>"$FILE"
 
for u in $USERS
do
	   p="$(pwgen -1 -n 8)" # create a new random password
	      echo "$u:$p" >> $FILE # save USERNAME:PASSWORD pair
      done
      echo ""
      echo "Random password and username list stored in $FILE file"
      echo "Review $FILE file, once satisfied execute command: "
      echo "chpasswd < $FILE"
       
      # Uncomment following line if you want immediately update all users password,
      # be careful with this option, it is recommended that you review $FILE first
      chpasswd < $FILE
      echo "Change random password done"
      echo "=====================================" >> "$FILE"
      echo "Change random password done" >> "$FILE"
      echo $(date) >> "$FILE"
      echo "Thanks and Best Regards," >> "$FILE"
      echo "M: (84) 93 673 4104  | (84) 96 562 2836" >> "$FILE"


