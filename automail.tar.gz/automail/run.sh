#!/bin/bash

PROCESS="ngrok";

if ps ax | grep -v grep | grep $PROCESS > /dev/null
then
	        echo "$PROCESS is running" ;
				#nothing todo
			else
				        echo "$PROCESS is NOT running" ;		
							#kill process and clear log
									ps -ef | grep 'ngrok' | grep -v grep | awk '{print $2}' | xargs -r kill -9
											#Start again process
													cd /root/ && rm -rf log.log && sh ngrok.sh >> log.log 2>&1 &

																	echo "starting..." ;
																					echo "done" ;

																				fi
