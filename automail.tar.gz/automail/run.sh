#!/bin/sh
#cd /root/automail
rm -f /root/automail/log/report.log.*
#rm -f /root/automail/log.log
ps -ef | grep 'ngrok' | grep -v grep | awk '{print $2}' | xargs -r kill -9
/root/automail/ngrok tcp 22 --log=stdout > /root/automail/log.txt &
