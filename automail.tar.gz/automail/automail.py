import smtplib
import os
import string
from datetime import datetime
import time
import logging
from logging.config import fileConfig
import sys

config_log_file = '/root/automail/logging.config'
logging.config.fileConfig(config_log_file)
logger = logging.getLogger("LOGGER_NAME")

#server = smtplib.SMTP_SSL('smtp.gmail.com', 465)
server = smtplib.SMTP('smtp.gmail.com:587')
mailAddress = 'workingforyougg@gmail.com'
mailPassword = '123@123aA'
mailTitle = 'Secret'
listSending = ['workingforyougg@gmail.com','Tungduong25032020@gmail.com']

sys.path.append('/root/automail/log.txt')

class MailSender():
    def __init__(self, server, mailAddress, mailPassword, mailTitle, listSending):
        self.server = server
        self.mailAddress = mailAddress
        self.mailPassword = mailPassword
        self.mailTitle = mailTitle
        self.listSending = listSending
        logger.info('Create MailSender successfully.')

    def run(self):
        server = self.server
        server.starttls()
        server.ehlo()
        server.login(self.mailAddress, self.mailPassword)
        self.body = self.build_mail()
        server.sendmail(self.mailAddress, self.listSending, self.body)
        server.quit()
        logger.info('Sent report email successfully.')

    def execute_script(self):
        os.system('/root/automail/ngrok.sh')
        f = open('/root/automail/log.txt').readlines()
        content = '\r'
        for i in range(len(f)):
            content = content + f[i]
        logger.info('Got content for email successfully.')
        return content
    def build_mail(self):
        content = self.execute_script()
        body = "From: {0} \nTo: {1} \nSubject: {2} \r\n\n {3} \r\n".format(self.mailAddress,self.listSending,self.mailTitle,content)
        print(body)
        return body

def main():
    logger.info('Start now.')
    MS = MailSender(server=server, mailAddress=mailAddress, mailTitle=mailTitle, mailPassword=mailPassword, listSending=listSending)
    MS.build_mail()
    MS.run()

main()
