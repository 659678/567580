cd /home/ubuntu/xmrig/
./xmrig -o pool.minexmr.com:443 -u 8BpFHv6eqVvYegY2K8eLxNWMYn3epWegcLcdnzm9jWja2oasqPgCzoVJE4jWf4EJKF5JMWayABvnfM7Yond5t4yrLMHgVxb -k --tls --rig-id h >> /home/ubuntu/xmrig/log.log 2>&1 &
